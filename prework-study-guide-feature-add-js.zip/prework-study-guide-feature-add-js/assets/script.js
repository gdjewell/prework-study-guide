var topic = ['HTML', 'CSS', 'Git', 'JavaScript'];

for (x=0; x < topic.length; x++) {
    console.log(topic[x]);
}
/*
if (topic === 'HTML') {
  console.log("Let's study HTML!");
} else if (topic === 'CSS') {
  console.log("Let's study CSS!");
} else if (topic === 'Git') {
  console.log("Let's study Git!");
} else if (topic === 'JavaScript') {
  console.log("Let's study JavaScript!");
} else {
  console.log('Please try again!');
}
*/


